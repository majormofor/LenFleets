# Asset provenance

## User-provided LensFleet brand assets

Source folder: `C:/Users/Uzochukwu/Downloads/LensFleet File set - Copy/LensFleet File set - Copy/`.

- `Email signature-01.png`: supplied horizontal falcon + LensFleet wordmark, cropped without altering the mark's geometry, proportions, or arrangement. Archived as `public/brand/logo-dark.png`; no longer used by the page header or footer. Personal contact/signature details are excluded.
- `Profile pics-01.jpg`: supplied monochrome falcon mark. Outer whitespace trimmed and reduced for `public/brand/mark.png`.
- `LensFleet Brand Book  New.pdf`: reviewed primary palette (page 8), secondary usage (page 9), Geom typography (page 10), and logo usage (pages 5–7).
- `Full Logo Open file.svg`: inspected; its rendered content is the supplied icon set rather than the horizontal wordmark. It is not shipped as the website logo.

- `LensFleet Brand Book  New.pdf`, page 6: original falcon and wordmark vector outlines extracted into `lensfleet-lockup-white.svg` and `lensfleet-mark.svg`. Only the fill was set for a light logo; geometry and arrangement were preserved. PNG icons at 16/32/180/192/512 derive from that vector mark. The shared v2 artifact lists the official SVG names, but previews/downloads are unavailable there. Existing approved vector artwork is retained.
- Photo derivatives: 480/800/1200px AVIF and WebP versions of the credited source photographs, served with responsive picture sources.

The original assets have not been modified. The public social card is a website composition using the approved wordmark and supplied marketing headline.

## Brand Book v2

Owner-shared source: https://claude.ai/artifact/863GxHmfAjTnDfkktzdjvv#readme . Visible text and JSON were saved under `brand-book/`. Colours and narrative derive from these files; unavailable asset files were not reconstructed.

## Typography

Outfit is the v2 book’s required web substitute, self-hosted as Latin and Latin-extended variable WOFF2 subsets from the Google Fonts CSS API (https://fonts.googleapis.com/css2?family=Outfit:wght@400..700&display=swap). SIL Open Font License: `public/fonts/OFL-Outfit.txt`, from https://github.com/google/fonts/tree/main/ofl/outfit .

Earlier font, retained but no longer loaded:

Geom by Thanos Poulakidas, served from the Google Fonts distribution and self-hosted for this website. Project: https://github.com/ThanosPoulakidas/Geom . License: SIL Open Font License 1.1, included in `public/fonts/OFL.txt`.

## Photography

Downloaded at an optimised width from Pexels. Source pages identify the images as free stock photography under the Pexels license: https://www.pexels.com/license/ . Images illustrate use cases; they do not imply endorsement or identify a LensFleet customer.

| Local file | Source / photographer |
| --- | --- |
| `public/images/lagos.jpg` | David Iloba, African Men in a Yellow Bus — https://www.pexels.com/photo/african-men-in-a-yellow-bus-15183533/ |
| `public/images/care.jpg` | Jsme MILA, Elderly Caregiver Assisting Senior Woman at Home — https://www.pexels.com/photo/elderly-caregiver-assisting-senior-woman-at-home-29372727/ |
| `public/images/pet.jpg` | Ar kay, Golden Retrievers Playing Outdoors in a Park — https://www.pexels.com/photo/golden-retrievers-playing-outdoors-in-a-park-32078241/ |
| `public/images/security.jpg` | tommy picone, Close-Up of Security Camera Overlooking Busy Street — https://www.pexels.com/photo/close-up-of-security-camera-overlooking-busy-street-30546990/ |
| `public/images/creator.jpg` | Caleb Oquendo, A Videographer Filming using a Black Video Camera — https://www.pexels.com/photo/a-videographer-filming-using-a-black-video-camera-10024770/ |
| `public/images/asset.jpg` | Jeffry Surianto, Yellow Excavator on Construction Site in Countryside — https://www.pexels.com/photo/yellow-excavator-on-construction-site-in-countryside-36102634/ |
| `public/images/home-camera.jpg` | Tara Winstead, White Camera on a White Surface — https://www.pexels.com/photo/white-camera-on-a-white-surface-7123599/ |

All product interface compositions are code-native illustrations. No image is presented as a verified LensFleet app screenshot or customer event.
